package edu.bu.cs622.hw4;

public class Constants {

	// connection info for mysql
	public static final String DB_URL = "jdbc:mysql://localhost:3306/met622?useTimezone=true&serverTimezone=UTC";
	public static final String USER = "root";
	public static final String PASSWORD = "root";
	
	// connection info for mongodb
	public static final String MONGO_DB_PATH = "met622";
	
	// sql create table statements
	public static final String ACTIVFIT_SQL = 
			"CREATE TABLE ACTIVFIT" +
			"(id INT AUTO_INCREMENT PRIMARY KEY," +
			"SENSOR_NAME VARCHAR(20)," +
			"START_TIME DATETIME," +
			"END_TIME DATETIME," +
			"ACTIVITY VARCHAR(20)," +
			"DURATION INT)";
	
	public static final String ACTIVITY_SQL = 
			"CREATE TABLE ACTIVITY" +
			"(id INT AUTO_INCREMENT PRIMARY KEY," +
			"SENSOR_NAME VARCHAR(20)," +
			"TIME DATETIME," +
			"STEP_COUNT INT," +
			"STEP_DELTA INT)";
 	
	public static final String BATTERY_SQL =
			"CREATE TABLE BATTERY" +
			"(id INT AUTO_INCREMENT PRIMARY KEY," +
			"SENSOR_NAME VARCHAR(20)," +
			"TIME TIMESTAMP," +
			"PERCENTAGE INT," +
			"CHARGING BOOLEAN)";
	
	public static final String HEARTRATE_SQL =
			"CREATE TABLE HEARTRATE" +
			"(id INT AUTO_INCREMENT PRIMARY KEY," +
			"SENSOR_NAME VARCHAR(20)," +
			"TIME DATETIME," +
			"BPM INT)";
	
	public static final String BLUETOOTH_SQL =
			"CREATE TABLE BLUETOOTH" +
			"(id INT AUTO_INCREMENT PRIMARY KEY," +
			"SENSOR_NAME VARCHAR(20)," +
			"TIME DATETIME," +
			"STATE VARCHAR(20))";
	
	public static final String LIGHT_SQL =
			"CREATE TABLE LIGHT" +
			"(id INT AUTO_INCREMENT PRIMARY KEY," +
			"SENSOR_NAME VARCHAR(20)," +
			"TIME DATETIME," +
			"LUX DOUBLE)";
	
	public static final String SCREEN_SQL =
			"CREATE TABLE SCREEN" +
			"(id INT AUTO_INCREMENT PRIMARY KEY," +
			"START_TIME DATETIME," +
			"END_TIME DATETIME," +
			"MINS_ELAPSED DOUBLE)";
}
